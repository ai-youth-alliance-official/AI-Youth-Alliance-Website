<?php
// Include the database connection file
include('../data/connect.php');
?>
